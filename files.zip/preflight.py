import json,glob
sheets={f:json.load(open(f,encoding='utf-8')) for f in sorted(glob.glob('*.json'))}
ids={r['id'] for rows in sheets.values() for r in rows}
refs=('hook','character','loot_table')
empty=0;bad=0
for f,rows in sheets.items():
    for r in rows:
        for k,v in r.items():
            if v is None or v is False and k in('verified','tested_two_copies'):
                print(f"VACÍO  {f} [{r['id']}].{k}");empty+=1
            if k in refs and isinstance(v,str) and v not in ids:
                print(f"REF ROTA {f} [{r['id']}].{k} -> {v}");bad+=1
print(f"\n{empty} celdas sin llenar/verificar, {bad} referencias rotas")
print("PREFLIGHT:", "LIMPIO" if empty==bad==0 else "NO LISTO PARA CONSTRUIR")
